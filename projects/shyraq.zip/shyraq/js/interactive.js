$(".hamburger").click(function(){
	$(".menu-mobile_panel").toggleClass("flex");
});
  var $hamburger = $(".hamburger");
  $hamburger.on("click", function(e) {
    $hamburger.toggleClass("is-active");
    // Do something else, like open/close menu
  });