$(".hamburger").click(function(){
	$(".menu-mobile_panel").toggleClass("flex");
});